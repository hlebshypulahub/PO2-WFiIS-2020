package com.company;

interface StudentUSOS {
    String toString();

    double srednia();

    void listaPrzedmiotow();
}