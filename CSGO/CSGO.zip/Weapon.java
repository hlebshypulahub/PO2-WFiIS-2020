package com.company;

public abstract class Weapon {

    public static void cut() { };

    public static String name_;

    Weapon(String name)
    {
        name_ = name;
    }

}
