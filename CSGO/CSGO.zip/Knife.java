package com.company;

public class Knife extends Weapon {

    public static void cut()
    {
        System.out.println("Slash!");
    }

    Knife()
    {
        super("Knife");
    }
}
