public interface CheckStep {
    boolean test(char[][] board, int x0, int y0, Direction dir);
}
